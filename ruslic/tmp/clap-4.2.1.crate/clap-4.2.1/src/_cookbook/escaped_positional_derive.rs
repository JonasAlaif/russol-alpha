//! # Example (Derive API)
//!
//! ```rust
#![doc = include_str!("../../examples/escaped-positional-derive.rs")]
//! ```
//!
#![doc = include_str!("../../examples/escaped-positional-derive.md")]
